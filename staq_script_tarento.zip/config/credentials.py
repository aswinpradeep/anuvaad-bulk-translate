#Credentials
ANUVAAD_USERNAME = "staq_hindi1@gmail.com"
ANUVAAD_PASSWORD = "Welcome@123"
